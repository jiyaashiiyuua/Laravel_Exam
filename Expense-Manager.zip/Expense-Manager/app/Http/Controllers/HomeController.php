<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Users;
use App\exCInsert;
use App\expenses;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {

       $role = \Auth::user()->admin;
        $userId = Auth::user();
       if($role == 1)
       {
          $one = DB::table('expenses')->distinct()->get(['category_name']);
          $expC = DB::select('select * from expenses');
         return view('Users.AdminDashboard',['expC'=>$expC])->with('userId',$userId)->with('one',$one);
        
       }
       else
        {
        
       
          $expC = DB::select('select * from expenses');
         return view('Users.AdminDashboard',['expC'=>$expC])->with('userId',$userId);
        }
    }

    public function addUser()
    {
      $role = \Auth::user()->admin;
      if($role == 1)
       {
    
      return view ('Users.addUsers');
      }
    }

     public function viewUser()
    {
      $role = \Auth::user()->admin;
      $users = Users::all();
      if($role == 1)
       {

        return view ('Users.viewUsers',  compact('users'));
       }
    }

     public function deleteUser ($userId)
    {
      $users = Users::findOrFail($userId);
       $users->delete();
      return redirect()->route('viewUser');
    }

    public function updateUser(Request $request, $id)
    {
      $this->validate($request,[
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'admin' => 'required',

      ]);

      $user = Users::find($id);

      $user->name   = $request->get('name');
      $user ->email = $request->get('email');
      $user->admin  = $request->get('admin');
      $user->save();
      return redirect()->route('viewUser');
    }

    public function expenseCategory(Request $request)
    {

      $expense_category = DB::select('select * from expense_category');
      return view('Users.expense_category',['expense_category'=>$expense_category]);
     
    }

     public function insertExpenseCategory(Request $request)
    {
         $rules = [
          'expense_category' => 'required|string',
          'description' => 'required|string',

        ];
        $validator = Validator::make($request->all(),$rules);
          if ($validator->fails()) {
            return redirect('expense_category')
            ->withInput()
            ->withErrors($validator);
          }
          else{
            $data = $request->input();
          try{
          $data = $request->input();
          $exC = new exCInsert;
          $exC->expense_category = $data['expense_category'];
          $exC->description = $data['description'];
          $exC->save();
          return redirect('expense_category')->with('status',"Insert successfully");
          }
          catch(Exception $e)
          {
            return redirect('expense_category')->with('failed',"operation failed");
          }
        }
    }

    public function updateCategory(Request $request, $id)
    {
      $rules = [
            'expense_category' => 'required|string',
            'description' => 'required|string',
      ];
      $validator = Validator::make($request->all(),$rules);
      if ($validator->fails()) {
            return redirect('expense_category')
            ->withInput()
            ->withErrors($validator);
          }
      else{
            $expid = exCInsert::find($id);
            try{
            $expid->expense_category = $request->get('expense_category');
            $expid ->description = $request->get('description');
           
            $expid->save();
           return redirect('expense_category')->with('status',"Update successfully");
             } 
             catch(Exception $e)
                {
                  return redirect('expense_category')->with('failed',"operation failed");
                }
          }
       }

     public function deleteCategory ($exP)
    {
      $exP = exCInsert::findOrFail($exP);
       $exP->delete();
      return redirect()->route('expenseCategory');
    }
   
    public function viewExpensesTable()
    {
      $userId = Auth::user();
      $role = \Auth::user()->admin;
      $expense_category = DB::select('select * from expense_category');
       $expenses = DB::select('select * from expenses');
      if($role == 1)
       {

        return view ('Users.viewExpenses',  compact('expense_category'))->with('userId',$userId)->with(compact('expenses'));
       }
       return view ('Users.viewExpenses',  compact('expense_category'))
              ->with('userId',$userId)
             ->with(compact('expenses'));
    }

     public function addExpenses(Request $request)
    {
         $rules = [
          'category_name' => 'required|string',
          'amount' => 'required|boolean',
          'date' => 'required'
        ];
       
          $data = $request->input();
          $Exp = new expenses;
          $Exp->category_name = $data['category_name'];
          $Exp->amount = $data['amount'];
          $Exp->date = $data['date'];
          $Exp->user_id = $data['user_id'];
          $Exp->save();
          return redirect('viewExpensesTable')->with('status',"Insert successfully");
        
    }         
}
