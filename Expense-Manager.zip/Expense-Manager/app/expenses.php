<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class expenses extends Model
{
      protected $table = 'expenses';
	public $timestamps = true;
	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = [
		'category_name', 'amount','user_id','date'
	];
}
